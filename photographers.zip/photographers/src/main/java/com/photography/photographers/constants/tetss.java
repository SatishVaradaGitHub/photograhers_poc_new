package com.photography.photographers.constants;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class tetss {
	
	public static void main(String[] args) {
		
		Date date1= new Date(2020, 12, 12);
		Date date2= new Date(2020, 12, 11);
		Date date3= new Date(2020, 12, 10);
		Date date4= new Date(2020, 12, 9);
		List<Map<String,Object>> list = new ArrayList<>();
		Map<String,Object> map = new HashMap<>();
		map.put("first",date1);
		map.put("first",date2);
		map.put("first",date3);
		map.put("first",date4);
		list.add(0, map);
		//Optional<Date> s1=null;
	list.forEach(element-> {
	//Optional<Integer> s=	element.values().stream().map((Date)date->date.getDate()).sorted(Comparator.reverseOrder()).findFirst();
    Optional<Date> s1=	element.values().stream().map(date->(Date) date).sorted(Comparator.naturalOrder()).findFirst();
	System.out.println(s1.get());
	
	});
		 
	}
	

}
